<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <strong>J</strong><span class = "small footerSubtext">ayawantrao</span>
                        <strong>S</strong><span class = "small footerSubtext">awant</span>
                        <strong>C</strong><span class = "small footerSubtext">ollege of</span>
                        <strong>E</strong><span class = "small footerSubtext">ngineering</span>
                    </p>

                    <p class = "footerSubtext2">
                    &copy; HAVEN Event Management    
                    Magarpatta IT Hub, Hadapsar, Pune
                        
                    </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                    A Project By : <br>
                    🔗 <a style="color:powderblue;" href="https://www.linkedin.com/in/azim-shaikh04/" target="_blank"> Azim Shaikh</a> <br>
                    🔗 <a style="color:powderblue;" href="https://www.linkedin.com/in/aditya-pardeshi-a2948024a/" target="_blank"> Aditya Pardeshi</a> <br>
                    🔗 <a style="color:powderblue;" href="https://www.linkedin.com/in/jay-surwase-945575231/" target="_blank"> Jay Surwase</a><br>
                    🔗 <a style="color:powderblue;" href="https://www.linkedin.com/in/kunal-shinde-43a316261/" target="_blank"> Kunal Shinde</a><br>
                    
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--right content-->
                    Follow Us:<br>
                    <a href="https://www.youtube.com/@marack4159" target="_blank"><img src = "images/youtube.png"></a>
                    <a href="https://www.facebook.com/jay.surwase.520" target="_blank"><img src = "images/facebook.png"></a>
                    <a href="https://twitter.com/AdiPardeshi1?t=I7LvGpPIdve_p_H7XiOP0A&s=08" target="_blank"><img src = "images/twitter.png"></a>   
                        
                        
                        
                </div>
            </section>
        </div>
    </div>
</footer>